import pandas as pd

def ensure_datetime_index(df: pd.DataFrame, ts_col: str = "timestamp") -> pd.DataFrame:
    if ts_col in df.columns:
        df[ts_col] = pd.to_datetime(df[ts_col])
        df = df.set_index(ts_col)
    if not isinstance(df.index, pd.DatetimeIndex):
        raise ValueError("El DataFrame debe tener un índice datetime.")
    return df
import csv
from datetime import datetime


def guardar_resultado_csv(
    crypto: str,
    days: int,
    precio_inicio: float,
    precio_fin: float,
    variacion_pct: float,
    recomendacion: str,
    archivo: str = "resultados.csv"
):
    """
    Guarda los resultados del análisis en un archivo CSV.
    """
    existe = False
    try:
        with open(archivo, "r", encoding="utf-8"):
            existe = True
    except FileNotFoundError:
        existe = False

    with open(archivo, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)

        if not existe:
            writer.writerow([
                "fecha",
                "criptomoneda",
                "dias",
                "precio_inicio",
                "precio_fin",
                "variacion_pct",
                "recomendacion"
            ])

        writer.writerow([
            datetime.now().strftime("%Y-%m-%d %H:%M"),
            crypto,
            days,
            round(precio_inicio, 2),
            round(precio_fin, 2),
            round(variacion_pct, 2),
            recomendacion
        ])
