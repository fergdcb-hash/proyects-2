import re
from exceptions import ValidationError

SYMBOL_REGEX = re.compile(r'^[A-Z0-9]{2,10}$')

def validate_symbol(symbol: str) -> bool:
    if not isinstance(symbol, str):
        raise ValidationError("Symbol debe ser una cadena.")
    if not SYMBOL_REGEX.match(symbol.strip().upper()):
        raise ValidationError(f"Símbolo inválido: {symbol}")
    return True
