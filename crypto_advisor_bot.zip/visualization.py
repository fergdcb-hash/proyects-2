import matplotlib.pyplot as plt
import pandas as pd

def plot_price_and_indicators(df: pd.DataFrame, title: str = "Price and Indicators"):
    plt.figure(figsize=(12, 6))
    plt.plot(df.index, df["price"], label="Price")
    if "sma_20" in df.columns:
        plt.plot(df.index, df["sma_20"], label="SMA20")
    if "sma_50" in df.columns:
        plt.plot(df.index, df["sma_50"], label="SMA50")
    plt.legend()
    plt.title(title)
    plt.xlabel("Date")
    plt.ylabel("Price (USD)")
    plt.grid(True)
    plt.show()

def plot_rsi(df: pd.DataFrame, title: str = "RSI"):
    plt.figure(figsize=(12, 4))
    plt.plot(df.index, df["rsi_14"], label="RSI(14)")
    plt.axhline(70, linestyle="--")
    plt.axhline(30, linestyle="--")
    plt.title(title)
    plt.show()
