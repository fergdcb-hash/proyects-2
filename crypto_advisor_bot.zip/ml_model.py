import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score


class CryptoMLModel:
    def __init__(self):
        self.model = RandomForestClassifier(
            n_estimators=100,
            random_state=42
        )

    def prepare_data(self, df: pd.DataFrame):
        df = df.copy()

        # Target: 1 si sube el precio al día siguiente
        df["target"] = (df["price"].shift(-1) > df["price"]).astype(int)

        features = [
    "sma_20",
    "sma_50",
    "ema_20",
    "rsi_14",
    "macd",
    "hist"
]


        df = df.dropna()

        X = df[features]
        y = df["target"]

        return X, y

    def train(self, df: pd.DataFrame):
        X, y = self.prepare_data(df)

        if len(X) < 20:
            return 0.0

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, shuffle=False
        )

        self.model.fit(X_train, y_train)

        preds = self.model.predict(X_test)
        acc = accuracy_score(y_test, preds)

        return acc

    def predict_next(self, df: pd.DataFrame):
        X, _ = self.prepare_data(df)
        last_row = X.iloc[[-1]]

        prediction = self.model.predict(last_row)[0]
        probability = self.model.predict_proba(last_row)[0][prediction]

        return prediction, probability
