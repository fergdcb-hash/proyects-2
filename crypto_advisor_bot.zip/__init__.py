from api_client import CoinGeckoClient
from advisor import CryptoAdvisor
self.ml_model = CryptoMLModel()
