import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

class TrendRegressor:
    def __init__(self):
        self.model = LinearRegression()

    def fit(self, df: pd.DataFrame, price_col: str = "price"):
        prices = df[price_col].values
        logp = np.log(prices + 1e-9)
        lr = np.diff(logp)
        X = np.arange(len(lr)).reshape(-1, 1)
        y = lr
        if len(X) < 2:
            raise ValueError("No hay suficientes datos para ajustar el modelo.")
        self.model.fit(X, y)
        return self

    def predict_daily_return(self, days: int = 1) -> float:
        x = np.arange(1, days + 1).reshape(-1, 1)
        preds = self.model.predict(x)
        return float(np.exp(preds.mean()) - 1)
