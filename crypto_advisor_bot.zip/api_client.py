import time
import requests
import pandas as pd
from exceptions import DataFetchError

class CoinGeckoClient:
    BASE = "https://api.coingecko.com/api/v3"

    def __init__(self, sleep_between_requests: float = 1.2):
        self.sleep = sleep_between_requests

    def get_market_chart(self, coin_id: str, vs_currency: str = "usd", days: int = 90) -> pd.DataFrame:
        url = f"{self.BASE}/coins/{coin_id}/market_chart"
        params = {"vs_currency": vs_currency, "days": days}
        try:
            r = requests.get(url, params=params, timeout=15)
        except requests.RequestException as e:
            raise DataFetchError(f"Error en la petición: {e}")
        if r.status_code != 200:
            raise DataFetchError(f"CoinGecko devolvió {r.status_code}: {r.text}")

        data = r.json()
        prices = data.get("prices", [])
        df = pd.DataFrame(prices, columns=["timestamp_ms", "price"])
        df["timestamp"] = pd.to_datetime(df["timestamp_ms"], unit="ms")
        df = df[["timestamp", "price"]]
        time.sleep(self.sleep)
        return df
