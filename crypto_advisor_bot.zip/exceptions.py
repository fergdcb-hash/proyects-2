class CryptoAdvisorError(Exception):
    pass

class DataFetchError(CryptoAdvisorError):
    pass

class ValidationError(CryptoAdvisorError):
    pass
