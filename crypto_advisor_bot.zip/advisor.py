from typing import Dict
import pandas as pd
from indicators import sma, ema, rsi, macd
from predictor import TrendRegressor


class CryptoAdvisor:
    def __init__(self, data_fetcher):
        self.fetcher = data_fetcher
        self.predictor = TrendRegressor()

    def analyze(self, coin_id: str, days: int = 90) -> Dict:
        # Obtener datos
        df = self.fetcher.get_market_chart(coin_id, days=days)
        df = df.sort_values("timestamp").reset_index(drop=True)
        df.set_index("timestamp", inplace=True)

        # ===============================
        # INDICADORES TÉCNICOS
        # ===============================
        df["sma_20"] = sma(df["price"], 20)
        df["sma_50"] = sma(df["price"], 50)
        df["ema_20"] = ema(df["price"], 20)
        df["rsi_14"] = rsi(df["price"], 14)

        mac_df = macd(df["price"])
        df = df.join(mac_df)

        # ===============================
        # PASO 2 — SEÑALES HISTÓRICAS
        # ===============================
        df["signal"] = "HOLD"

        for i in range(1, len(df)):
            if (
                df["sma_20"].iloc[i] > df["sma_50"].iloc[i]
                and df["sma_20"].iloc[i - 1] <= df["sma_50"].iloc[i - 1]
            ):
                df.iloc[i, df.columns.get_loc("signal")] = "BUY"

            elif (
                df["sma_20"].iloc[i] < df["sma_50"].iloc[i]
                and df["sma_20"].iloc[i - 1] >= df["sma_50"].iloc[i - 1]
            ):
                df.iloc[i, df.columns.get_loc("signal")] = "SELL"

        # ===============================
        # RESAMPLE Y PREDICCIÓN
        # ===============================
        daily = df.select_dtypes(include="number").resample("D").mean()

        try:
            self.predictor.fit(daily.reset_index(), price_col="price")
            expected_return = self.predictor.predict_daily_return(days=1)
        except Exception:
            expected_return = 0.0

        # ===============================
        # MACHINE LEARNING
        # ===============================
        try:
            from ml_model import CryptoMLModel

            ml_model = CryptoMLModel()
            ml_accuracy = ml_model.train(df)
            ml_pred, ml_prob = ml_model.predict_next(df)

        except Exception as e:
            print("Error ML:", e)
            ml_accuracy = 0.0
            ml_pred = None
            ml_prob = None

        # ===============================
        # RECOMENDACIÓN FINAL
        # ===============================
        recommendation = self._rule_based_recommendation(df, expected_return)

        # ===============================
        # RETURN
        # ===============================
        return {
            "data": df,
            "daily": daily,
            "expected_return": expected_return,
            "recommendation": recommendation,
            "ml": {
                "prediction": ml_pred,
                "probability": ml_prob,
                "accuracy": ml_accuracy
            }
        }

    def _rule_based_recommendation(
        self, df: pd.DataFrame, expected_return: float
    ) -> Dict:

        reasons = []
        last = df.iloc[-1]
        prev = df.iloc[-2] if len(df) > 1 else last
        signal = "HOLD"

        if prev["sma_20"] < prev["sma_50"] and last["sma_20"] > last["sma_50"]:
            reasons.append("Cruce alcista SMA20 sobre SMA50")
            signal = "BUY"

        if prev["sma_20"] > prev["sma_50"] and last["sma_20"] < last["sma_50"]:
            reasons.append("Cruce bajista SMA20 por debajo SMA50")
            signal = "SELL"

        if last["rsi_14"] > 70:
            reasons.append(f"RSI alto ({last['rsi_14']:.1f})")
            signal = "SELL"
        elif last["rsi_14"] < 30:
            reasons.append(f"RSI bajo ({last['rsi_14']:.1f})")
            signal = "BUY"

        if expected_return > 0.005:
            reasons.append(f"Retorno esperado positivo ≈ {expected_return*100:.2f}%")
            if signal == "HOLD":
                signal = "BUY"
        elif expected_return < -0.005:
            reasons.append(f"Retorno esperado negativo ≈ {expected_return*100:.2f}%")
            if signal == "HOLD":
                signal = "SELL"

        if not reasons:
            reasons.append("No hay señales claras. Mantener posición.")

        return {"signal": signal, "reasons": reasons}

