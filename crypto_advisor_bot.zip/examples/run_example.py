import sys
import os

# =====================================================
# AÑADIR LA RUTA DEL PROYECTO AL PATH (MUY IMPORTANTE)
# =====================================================
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.append(PROJECT_ROOT)

# =====================================================
# IMPORTS DEL PROYECTO
# =====================================================
from api_client import CoinGeckoClient
from advisor import CryptoAdvisor
from visualization import plot_price_and_indicators, plot_rsi
from backtesting import backtest_signals
from exceptions import DataFetchError


def main():
    # =================================================
    # 1) ENTRADA DEL USUARIO
    # =================================================
    coin = input(
        "Escribe el ID de la criptomoneda (ej: bitcoin, ethereum): "
    ).strip().lower()

    days_str = input("¿Cuántos días quieres analizar? (ej: 30, 60, 90): ").strip()
    try:
        days = int(days_str)
    except ValueError:
        print("Valor no válido, se usarán 90 días.")
        days = 90

    # =================================================
    # 2) CREAR CLIENTE Y ADVISOR
    # =================================================
    client = CoinGeckoClient()
    advisor = CryptoAdvisor(client)

    # =================================================
    # 3) ANALIZAR CRIPTOMONEDA
    # =================================================
    try:
        result = advisor.analyze(coin_id=coin, days=days)
    except DataFetchError as e:
        print("\n❌ Error al obtener datos:")
        print(e)
        return

    df = result["data"]
    rec = result["recommendation"]
    ml = result["ml"]

    # =================================================
    # 4) MACHINE LEARNING
    # =================================================
    print("\n🧠 MACHINE LEARNING")
    print(f"- Precisión del modelo: {ml['accuracy']*100:.2f}%")

    if ml["prediction"] == 1:
        print(f"- Predicción ML: SUBIDA (confianza {ml['probability']*100:.1f}%)")
    elif ml["prediction"] == 0:
        print(f"- Predicción ML: BAJADA (confianza {ml['probability']*100:.1f}%)")
    else:
        print("- Predicción ML: no disponible")

    # =================================================
    # 5) BACKTESTING HISTÓRICO
    # =================================================
    bt = backtest_signals(df, initial_capital=1000)

    print("\n📊 RESULTADO DEL BACKTESTING")
    print(f"- Capital inicial: {bt['initial_capital']} USD")
    print(f"- Capital final:   {bt['final_value']} USD")
    print(f"- Retorno total:   {bt['return_pct']}%")
    print(f"- Nº operaciones: {len(bt['trades'])}")

    # =================================================
    # 6) EVOLUCIÓN DEL PRECIO
    # =================================================
    price_start = df["price"].iloc[0]
    price_end = df["price"].iloc[-1]
    pct_change = (price_end / price_start - 1) * 100

    print("\n📈 EVOLUCIÓN DE LA CRIPTOMONEDA")
    print(f"- Días analizados: {days}")
    print(f"- Precio inicial:  {price_start:.2f} USD")
    print(f"- Precio final:    {price_end:.2f} USD")
    print(f"- Variación total: {pct_change:+.2f}%")

    # =================================================
    # 7) RECOMENDACIÓN DEL BOT
    # =================================================
    print("\n🤖 RECOMENDACIÓN DEL BOT")
    print("→ Señal:", rec["signal"])
    print("→ Motivos:")
    for r in rec["reasons"]:
        print("  -", r)

    # =================================================
    # 8) GRÁFICOS
    # =================================================
    print("\n📊 Mostrando gráficas...")
    plot_price_and_indicators(df, title=f"{coin.capitalize()} - Precio e Indicadores")
    plot_rsi(df, title=f"{coin.capitalize()} - RSI")

    input("\nPulsa ENTER para salir...")


if __name__ == "__main__":
    main()
