# Crypto Advisor Bot

Proyecto final desarrollado en Python que implementa un bot de análisis del mercado de criptomonedas. El sistema obtiene datos reales desde la API de CoinGecko, calcula indicadores técnicos, realiza backtesting histórico y utiliza Machine Learning para apoyar la toma de decisiones.

---

## 📌 Funcionalidades principales

- Obtención de datos reales desde CoinGecko
- Cálculo de indicadores técnicos (SMA, EMA, RSI, MACD)
- Generación de señales BUY / SELL / HOLD
- Visualización de resultados con gráficas
- Backtesting histórico de la estrategia
- Modelo de Machine Learning para predicción de tendencia
- Exportación de resultados

---

## 📁 Estructura del proyecto

- `api_client.py` → conexión con CoinGecko  
- `advisor.py` → núcleo del sistema de análisis  
- `indicators.py` → indicadores técnicos  
- `backtesting.py` → simulación histórica  
- `ml_model.py` → modelo de Machine Learning  
- `visualization.py` → gráficas  
- `exceptions.py` → excepciones personalizadas  
- `validators.py` → validación de datos  
- `examples/run_example.py` → ejecutable principal  
- `text.ipynb` → notebook explicativo  

---

## ▶️ Cómo ejecutar el proyecto

Desde la carpeta raíz:

```bash
python examples/run_example.py
