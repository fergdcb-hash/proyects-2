import pandas as pd


def backtest_signals(
    df: pd.DataFrame,
    initial_capital: float = 1000.0
):
    """
    Simula un backtesting sencillo usando señales BUY / SELL.
    """
    capital = initial_capital
    position = 0.0
    trades = []

    for i in range(1, len(df)):
        price = df["price"].iloc[i]
        signal = df["signal"].iloc[i]

        if signal == "BUY" and capital > 0:
            position = capital / price
            capital = 0
            trades.append(("BUY", df.index[i], price))

        elif signal == "SELL" and position > 0:
            capital = position * price
            position = 0
            trades.append(("SELL", df.index[i], price))

    final_value = capital
    if position > 0:
        final_value = position * df["price"].iloc[-1]

    return {
        "initial_capital": initial_capital,
        "final_value": round(final_value, 2),
        "return_pct": round((final_value / initial_capital - 1) * 100, 2),
        "trades": trades
    }


